# Kompendium — App

Persoenliche Bibliothek fuer selbstgebaute HTML-Dokumente.
React Native / Expo SDK 57 (React Native 0.86), Android-first, mobile only.

Verbindliche Vorgabe ist das Handoff-Dokument
`C:\Projekte\HTML-Dokumenten-Ordner\README.md`. Bei Widerspruechen gilt es.

## Start

```bash
npm install
cp .env.example .env      # Supabase-Zugangsdaten eintragen
npx expo start
```

Danach den QR-Code mit Expo Go scannen (Expo Go fuer SDK 57).

Abweichung vom Loesungskonzept: dort ist SDK 54 gepinnt, weil Expo Go dafuer
regulaer in den Stores liegt. Auf dem Zielgeraet ist Expo Go fuer SDK 57
installiert, deshalb gilt hier 57 (React Native 0.86, React 19.2, Reanimated 4.5).

## Supabase

1. Projekt anlegen, unter *Project Settings > API* die URL und den
   Publishable/Anon Key kopieren, in `.env` eintragen.
2. `supabase/schema.sql` im SQL-Editor ausfuehren. Legt Tabellen, Indizes,
   Volltextsuche, `updated_at`-Trigger, RLS-Policies und den privaten
   Storage-Bucket `documents` an.
3. Unter *Authentication > Sign In / Providers* **Anonymous sign-ins**
   aktivieren — die App meldet sich ohne Login-Screen an.

Ohne `.env` startet die App trotzdem und laeuft rein lokal.

## Struktur

```
app/(tabs)/           Bibliothek, Ordner, Tags, Einstellungen
app/dokument/[id]     Viewer als Push-Screen, ohne Tab-Bar
app/ordner/[name]     Ordner-Detail als Push-Screen
app/alle-dokumente    "Alle Dokumente" — kein Ordner, eigene Route
app/suche.tsx         Suche als Push-Screen, ohne Tab-Bar
app/abnahme.tsx       Abnahmeblaetter als Push-Screen
src/theme/            Design-Tokens — einzige Stelle mit Hex-Werten
src/ui/               Basiskomponenten, Kachel und Icon-Register
src/screens/          Screens; jeder in einem eigenen Ordner
src/state/            Zustand, der Screens ueberdauert (zustand)
src/data/             Supabase-Client, Formate, Beispiel-Bestand, Suchlauf
src/dev/              Abnahmeblaetter (Tokens, Kacheln, Komponenten)
scripts/lint-tokens   Prueft: keine freihaendigen Farb- oder Schriftwerte
scripts/shots.mjs     Screenshots des Viewer-Kernflows
scripts/shots6.mjs    Screenshots der Screens aus Schritt 6
supabase/schema.sql   Datenbankschema
```

## Pruefungen

```bash
npm run typecheck     # tsc --noEmit
npm run lint:tokens   # keine freihaendigen Hex-Codes ausserhalb des Themes
```

`react-native-web` liegt nur in devDependencies: damit laesst sich der Stand mit
`npx expo start --web` im Browser ansehen und als Bild gegen den Prototyp
halten. Zielplattform bleibt mobile only.

```bash
npx expo export --platform web
cd dist && python3 -m http.server 8099    # die Seite unter / laden, nicht /index.html
node scripts/shots.mjs http://127.0.0.1:8099 /tmp/shots
```

Der Viewer nutzt auf Web nicht `react-native-webview` — das Paket hat dort
keine Umsetzung — sondern ueber `DocumentView.web.tsx` ein `iframe`. Das
Aus- und Einblenden der Bedienung laesst sich im Web-Bild deshalb nicht
pruefen: der Scrollversatz eines fremden Dokuments ist von aussen nicht
lesbar.

Die Abnahmeblaetter liegen unter `src/dev/` und sind ueber **Einstellungen >
Abnahmeblaetter** erreichbar: **Tokens** (`1a`), **Kacheln** (`1b`),
**Komponenten** (`2a`).

## Daten

Die Bibliothek rendert bis auf Weiteres aus `src/data/sampleLibrary.ts` — 247
Dokumente, die ersten davon die aus den Blaettern `1c` und `1d`. Die Screens
kennen nur den Typ `LibraryDocument`; der Wechsel auf expo-sqlite beruehrt also
keine Komponente.

Was in den Sheets geaendert wird (Titel, Ordner, Tags, Notiz, "Offline
behalten", Zaehler "Geoeffnet", Papierkorb), liegt in `src/state/documents.ts`
als Ueberlagerung ueber diesem Bestand — auch die Tag-Liste, weil neue Tags im
Tag-Sheet entstehen. Der Bestand selbst bleibt unveraendert.

Ordner liegen in `src/state/folders.ts`. Ihr Name ist zugleich ihr Ausweis,
solange es keine Datenbank gibt; Umbenennen wirkt deshalb in beiden Speichern.

Die Suche (`src/data/search.ts`) laeuft ueber Titel, Ordner, Tags und den Text
aus `sampleDocumentHtml`. Sobald der Dateicache echte Dokumente liefert, tauscht
dort nur die Textquelle — Trefferzeile und Screen bleiben unberuehrt.

Den Inhalt der Dokumente erzeugt `src/data/sampleDocumentHtml.ts`, bis der
Import den Dateicache fuellt. Das ist ausdruecklich Beispielinhalt: echte
Dokumente bringen ihre eigene Gestaltung mit, die App legt kein Stylesheet
darueber.

## Stand

- [x] Projektgeruest, Supabase-Schema und -Client
- [x] Schritt 1 — Theme-Modul mit allen Tokens, Inter, Phosphor, Token-Uebersicht
- [x] Schritt 2 — Kachel-Komponente `DocTile` mit Hash-Farbton und fuenf Mustern
- [x] Schritt 3 — 18 Basiskomponenten aus Blatt `2a`, Abnahmeblatt "Komponenten"
- [x] Schritt 4 — Bibliothek in Liste und Kacheln, Sektion "Neu", kollabierender
      Header, Tab-Rahmen mit Platzhaltern fuer Ordner, Tags und Einstellungen
- [x] Schritt 5 — Viewer mit WebView, Chrome-Autohide und schwebendem
      Aktionsbalken; Info-Sheet und Tag-Sheet als Kernflow, Toast mit
      "Rueckgaengig"
- [x] Schritt 6 — Ordner-Uebersicht und -Detail, Tag-Verwaltung mit
      Wischaktionen, Suche in drei Zustaenden, Import-Sheet, Mehrfachauswahl;
      dazu die Sheets "Ordner anlegen", "Umbenennen" und "Verschieben"
- [ ] Schritt 7 — Einstellungen mit Papierkorb und Darstellung
- [ ] Schritt 8 — Zustaende: leer, laden, offline, Sync-Fehler, kein Cache

### Offen aus Schritt 6

- Die drei Import-Wege (Datei, Zwischenablage, URL) sind noch ohne Wirkung. Sie
  brauchen den lokalen Dateicache und die Typerkennung beim Import; beides
  gehoert zur Datenschicht.
- "Loeschen" legt Dokumente in den Papierkorb (`trashedAt` im Dokument-Zustand)
  und blendet sie aus allen Listen aus. Der Papierkorb-Screen (`6a`) kommt in
  Schritt 7 — bis dahin ist der Rueckweg allein der Toast mit "Rueckgaengig".
- Sortierung der Ordner ("Name" / "Anzahl") und das Verschieben-Sheet haben kein
  eigenes Blatt im Prototyp; beide sind aus vorhandenen Teilen gebaut.
