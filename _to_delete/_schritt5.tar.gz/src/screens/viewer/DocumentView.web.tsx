/**
 * Dokumentflaeche fuer den Web-Export.
 *
 * `react-native-webview` hat keine Web-Umsetzung und zeichnet dort nur den
 * Hinweis "does not support this platform". Der Web-Build ist im Projekt
 * ausdruecklich nur die Bildkontrolle gegen den Prototyp (README, Abschnitt
 * "Pruefungen") — deshalb steht hier ein `iframe` mit `srcDoc`, das dieselbe
 * Seite rendert. Zielplattform bleibt mobile only.
 *
 * Der Scrollversatz laesst sich aus einem fremden `iframe`-Dokument nicht
 * ablesen; das Aus- und Einblenden der Bedienung ist im Web-Bild also nicht zu
 * pruefen. Beide Zustaende sind stattdessen ueber die Abnahmeblaetter
 * erreichbar.
 */
import React from 'react';
import { StyleSheet, View } from 'react-native';

import { bg } from '../../theme';
import type { DocumentViewProps } from './DocumentView';

export function DocumentView({ html, onLoaded }: DocumentViewProps) {
  return (
    <View style={styles.stage}>
      {React.createElement('iframe', {
        srcDoc: html,
        onLoad: onLoaded,
        title: 'Dokument',
        style: {
          border: 'none',
          width: '100%',
          height: '100%',
          display: 'block',
        },
      })}
    </View>
  );
}

const styles = StyleSheet.create({
  stage: {
    flex: 1,
    backgroundColor: bg.base,
  },
});
