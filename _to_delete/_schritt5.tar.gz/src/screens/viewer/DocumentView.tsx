/**
 * Die Dokumentflaeche des Viewers — eine WebView mit lokalem HTML.
 *
 * Sie meldet zwei Dinge nach oben: den Scrollversatz (daraus entsteht das
 * Aus- und Einblenden der Bedienung) und den Ladeabschluss. Die Buehne bleibt
 * bis dahin auf `bg/base`, damit kein weisses Bild aufblitzt — deshalb liegt
 * die WebView selbst zunaechst durchsichtig darueber.
 *
 * Fuer den Web-Export gibt es `DocumentView.web.tsx`: `react-native-webview`
 * hat auf Web keine Umsetzung und zeichnet dort nur einen Hinweis. Da der
 * Web-Build allein der Bildkontrolle gegen den Prototyp dient, uebernimmt
 * dort ein `iframe` dieselbe Aufgabe.
 */
import React, { useRef, useState } from 'react';
import { Animated, StyleSheet, View } from 'react-native';
import { WebView, type WebViewProps } from 'react-native-webview';

import { bg, duration, easingNative } from '../../theme';

export interface DocumentViewProps {
  /** Vollstaendige HTML-Seite. */
  html: string;
  /** Leseposition beim Oeffnen, in dp. */
  initialOffset?: number;
  onScroll?: (offset: number) => void;
  onLoaded?: () => void;
}

export function DocumentView({ html, initialOffset = 0, onScroll, onLoaded }: DocumentViewProps) {
  const opacity = useRef(new Animated.Value(0)).current;
  const [ready, setReady] = useState(false);

  /**
   * Die WebView meldet ihr Scroll-Ereignis in der Form, die der native
   * Baustein liefert; nach aussen geht nur der Versatz.
   */
  const handleWebViewScroll: WebViewProps['onScroll'] = (event) => {
    onScroll?.(event.nativeEvent.contentOffset.y);
  };

  const reveal = () => {
    if (ready) return;
    setReady(true);
    onLoaded?.();
    Animated.timing(opacity, {
      toValue: 1,
      duration: duration.micro,
      easing: easingNative.micro,
      useNativeDriver: true,
    }).start();
  };

  return (
    <View style={styles.stage}>
      <Animated.View style={[styles.fill, { opacity }]}>
        <WebView
          source={{ html }}
          style={styles.web}
          // Die Buehne liegt darunter; eine eigene Flaeche wuerde beim Laden
          // als heller Blitz erscheinen.
          containerStyle={styles.transparent}
          originWhitelist={['*']}
          // Eigene Dokumente, kein fremder Code: Skripte laufen, Navigation
          // nach aussen bleibt aus.
          javaScriptEnabled
          setSupportMultipleWindows={false}
          onShouldStartLoadWithRequest={(request) => request.url.startsWith('about:')}
          onLoadEnd={reveal}
          onScroll={handleWebViewScroll}
          // Leseposition wiederherstellen, bevor das Bild sichtbar wird.
          injectedJavaScript={`window.scrollTo(0, ${Math.round(initialOffset)}); true;`}
          showsVerticalScrollIndicator={false}
          overScrollMode="never"
          allowsBackForwardNavigationGestures={false}
        />
      </Animated.View>
    </View>
  );
}

const styles = StyleSheet.create({
  stage: {
    flex: 1,
    backgroundColor: bg.base,
  },
  fill: {
    flex: 1,
  },
  web: {
    flex: 1,
    backgroundColor: bg.base,
  },
  transparent: {
    backgroundColor: bg.base,
  },
});
