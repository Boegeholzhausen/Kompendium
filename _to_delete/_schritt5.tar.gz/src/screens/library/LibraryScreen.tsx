/**
 * Screen 1 und 2 — Bibliothek in Listen- und Kachelansicht (Blaetter `1c`, `1d`).
 *
 * Startbildschirm der App. Wiederfinden ist die haeufigste Aufgabe, deshalb
 * steht ueber der Liste das Suchfeld, darunter die Filterleiste, und erst
 * darunter beginnt der Bestand.
 *
 * Aufbau:
 *   schwebender Kopf   Kopfzeile + Sync-Leiste + Filterleiste (LibraryHeader)
 *   Liste              Suchfeld, Platzhalter fuer die Filterleiste, Sektion
 *                      "Neu", Sektionskopf, Dokumentzeilen bzw. Kacheln
 *   FAB                Importieren, 16 vom rechten Rand, 112 ueber der Kante
 *
 * Warum der Kopf schwebt und nicht in der Liste steht: er schrumpft beim
 * Scrollen von 68 auf 56. Stuende er im Inhalt, wuerde jeder Schrumpfschritt
 * die Liste unter dem Finger verschieben. Als schwebende Ebene aendert er nur
 * sich selbst; der Inhalt haelt seinen Innenabstand oben (`CONTENT_TOP`) und
 * scrollt darunter durch.
 *
 * Die 247 Dokumente kommen aus `src/data/sampleLibrary`, bis die lokale
 * Datenbank steht. Die Liste rendert virtualisiert — sie muss auch mit dem
 * vollen Bestand ruhig bleiben.
 */
import React, { useCallback, useMemo, useState } from 'react';
import { StyleSheet, View, type ListRenderItemInfo } from 'react-native';
import Animated, {
  runOnJS,
  useAnimatedReaction,
  useAnimatedScrollHandler,
  useSharedValue,
} from 'react-native-reanimated';
import { useSafeAreaInsets } from 'react-native-safe-area-context';
import { useRouter } from 'expo-router';

import { formatDocumentMeta } from '../../data/format';
import {
  isNewDocument,
  sampleDocuments,
  sampleSyncStatus,
  type LibraryDocument,
} from '../../data/sampleLibrary';
import { documentTags, useDocumentStore } from '../../state/documents';
import { useLibraryStore } from '../../state/library';
import { bg, size, space } from '../../theme';
import { DocCard } from '../../ui/DocCard';
import { DocRow } from '../../ui/DocRow';
import { Fab } from '../../ui/Fab';
import { SearchField } from '../../ui/SearchField';
import { SectionHeader } from '../../ui/SectionHeader';
import { LibraryHeader } from './LibraryHeader';
import { CHIPS_SPACER, COLLAPSE_DISTANCE, CONTENT_TOP } from './metrics';
import { NewSection } from './NewSection';
import { SortSheet } from './SortSheet';

export function LibraryScreen() {
  const insets = useSafeAreaInsets();
  const router = useRouter();

  const viewMode = useLibraryStore((state) => state.viewMode);
  const sort = useLibraryStore((state) => state.sort);
  const activeFilter = useLibraryStore((state) => state.activeFilter);
  const favorites = useLibraryStore((state) => state.favorites);
  const toggleViewMode = useLibraryStore((state) => state.toggleViewMode);
  const setSort = useLibraryStore((state) => state.setSort);
  const setFilter = useLibraryStore((state) => state.setFilter);
  const toggleFavorite = useLibraryStore((state) => state.toggleFavorite);

  /**
   * Titel und Tags kommen seit Schritt 5 aus dem Dokument-Zustand: was im
   * Info- oder Tag-Sheet geaendert wird, muss beim Zurueckgehen sofort in der
   * Zeile stehen. Der Bestand liefert weiterhin alles Unveraenderliche.
   */
  const titles = useDocumentStore((state) => state.titles);
  const tagIds = useDocumentStore((state) => state.tagIds);
  const tags = useDocumentStore((state) => state.tags);

  const [sortOpen, setSortOpen] = useState(false);
  /**
   * Kommt aus dem Scrolloffset und lebt nur, solange der Screen sichtbar ist.
   * Er schaltet die Chips zwischen 40 und 36 um — dazwischen gibt es nichts,
   * also faellt die Entscheidung bei halbem Weg.
   */
  const [collapsed, setCollapsed] = useState(false);

  const scrollY = useSharedValue(0);
  const onScroll = useAnimatedScrollHandler((event) => {
    scrollY.value = event.contentOffset.y;
  });

  useAnimatedReaction(
    () => scrollY.value > COLLAPSE_DISTANCE / 2,
    (next, previous) => {
      if (next !== previous) runOnJS(setCollapsed)(next);
    }
  );

  const documents = useMemo(() => {
    const filtered = sampleDocuments.filter((document) => {
      if (activeFilter === 'all') return true;
      if (activeFilter === 'favorites') return favorites[document.id] === true;
      return (tagIds[document.id] ?? []).includes(activeFilter);
    });

    const sorted = [...filtered];
    if (sort === 'title') {
      sorted.sort((a, b) =>
        (titles[a.id] ?? a.title).localeCompare(titles[b.id] ?? b.title, 'de')
      );
    } else if (sort === 'size') {
      sorted.sort((a, b) => b.sizeBytes - a.sizeBytes);
    } else {
      sorted.sort((a, b) => b.updatedAt - a.updatedAt);
    }
    return sorted;
  }, [activeFilter, favorites, sort, tagIds, titles]);

  const newDocuments = useMemo(() => sampleDocuments.filter(isNewDocument), []);

  /**
   * Die Zeile skaliert beim Druck (steckt in `PressableScale`), dann schiebt
   * der Viewer von rechts ein — den Uebergang liefert der Stack.
   */
  const openDocument = useCallback(
    (document: LibraryDocument) => {
      router.push(`/dokument/${document.id}`);
    },
    [router]
  );

  // Suchscreen und Import-Sheet entstehen in Schritt 6.
  const openSearch = useCallback(() => {}, []);
  const sortIn = useCallback(() => {}, []);

  const isGrid = viewMode === 'grid';

  const header = (
    <View>
      <View style={styles.searchBlock}>
        <SearchField interactive={false} onPress={openSearch} />
      </View>

      {/* Platzhalter unter der schwebenden Filterleiste. */}
      <View style={styles.chipsSpacer} />

      {isGrid ? null : (
        <>
          <View style={styles.newSection}>
            <NewSection documents={newDocuments} onOpen={openDocument} onSortIn={sortIn} />
          </View>
          <SectionHeader
            title="Alle Dokumente"
            count={documents.length}
            style={styles.sectionHeader}
          />
        </>
      )}
    </View>
  );

  const renderItem = useCallback(
    ({ item, index }: ListRenderItemInfo<LibraryDocument>) => {
      const favorite = favorites[item.id] === true;

      const title = titles[item.id] ?? item.title;

      if (isGrid) {
        return (
          <DocCard
            id={item.id}
            title={title}
            type={item.docType}
            folderName={item.folderName}
            favorite={favorite}
            unavailable={!item.cached}
            state={item.cached ? 'default' : 'unavailable'}
            onPress={() => openDocument(item)}
            onToggleFavorite={() => toggleFavorite(item.id)}
            style={styles.gridCard}
          />
        );
      }

      return (
        <View style={styles.rowWrap}>
          <DocRow
            id={item.id}
            title={title}
            type={item.docType}
            meta={formatDocumentMeta(item.updatedAt, item.sizeBytes)}
            tagColors={documentTags(tags, tagIds[item.id] ?? []).map((tag) => tag.color)}
            favorite={favorite}
            unavailable={!item.cached}
            last={index === documents.length - 1}
            onPress={() => openDocument(item)}
            onToggleFavorite={() => toggleFavorite(item.id)}
          />
        </View>
      );
    },
    [documents.length, favorites, isGrid, openDocument, tagIds, tags, titles, toggleFavorite]
  );

  return (
    <View style={styles.screen}>
      <Animated.FlatList
        // numColumns laesst sich nicht im laufenden Betrieb aendern; der
        // Schluessel baut die Liste beim Ansichtswechsel neu auf.
        key={viewMode}
        data={documents}
        renderItem={renderItem}
        keyExtractor={(item: LibraryDocument) => item.id}
        numColumns={isGrid ? 2 : 1}
        columnWrapperStyle={isGrid ? styles.gridRow : undefined}
        ListHeaderComponent={header}
        onScroll={onScroll}
        scrollEventThrottle={16}
        contentContainerStyle={[
          {
            paddingTop: insets.top + CONTENT_TOP,
            // FAB und Tab-Bar duerfen keine Zeile verdecken.
            paddingBottom: size.listBottomPadding + insets.bottom,
          },
          isGrid ? styles.gridContent : null,
        ]}
        showsVerticalScrollIndicator={false}
        initialNumToRender={12}
        windowSize={7}
      />

      <LibraryHeader
        scrollY={scrollY}
        collapsed={collapsed}
        viewMode={viewMode}
        onToggleViewMode={toggleViewMode}
        onOpenSort={() => setSortOpen(true)}
        syncStatus={sampleSyncStatus}
        activeFilter={activeFilter}
        onSelectFilter={setFilter}
        top={insets.top}
      />

      <Fab withTabBar onPress={sortIn} accessibilityLabel="Dokument importieren" />

      <SortSheet
        visible={sortOpen}
        value={sort}
        onSelect={setSort}
        onClose={() => setSortOpen(false)}
      />
    </View>
  );
}

const styles = StyleSheet.create({
  screen: {
    flex: 1,
    backgroundColor: bg.base,
  },
  searchBlock: {
    paddingTop: size.screenPadding,
    paddingHorizontal: size.screenPadding,
  },
  chipsSpacer: {
    height: CHIPS_SPACER,
  },
  newSection: {
    marginTop: size.screenPadding,
  },
  sectionHeader: {
    marginTop: space['24'],
    marginBottom: space['8'],
    paddingHorizontal: size.screenPadding,
  },
  rowWrap: {
    paddingHorizontal: size.screenPadding,
  },
  gridContent: {
    gap: space['16'],
  },
  gridRow: {
    gap: space['12'],
    paddingHorizontal: size.screenPadding,
  },
  gridCard: {
    flex: 1,
  },
});
