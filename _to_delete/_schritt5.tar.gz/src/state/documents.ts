/**
 * Zustand einzelner Dokumente — alles, was das Info- und das Tag-Sheet aendern.
 *
 * Das Handoff-Dokument listet unter "State Management" fuer ein Dokument
 * `title`, `folderId`, `tagIds[]`, `note`, `isFavorite`, `keepOffline`,
 * `openCount` und weitere Felder. Die Wahrheitsquelle wird expo-sqlite; bis
 * dahin liegen die Aenderungen hier als Ueberlagerung ueber dem Bestand aus
 * `src/data/sampleLibrary`. Die Screens fragen nur diesen Zustand — der
 * Wechsel auf die Datenbank beruehrt keine Komponente.
 *
 * `isFavorite` bleibt bewusst im Bibliothek-Zustand: der Stern gehoert zur
 * Zeile und wird dort seit Schritt 4 umgeschaltet. Zwei Speicherorte fuer
 * denselben Schalter waeren eine Fehlerquelle.
 *
 * Die Tag-Liste liegt ebenfalls hier und nicht im Bestand, weil neue Tags im
 * Tag-Sheet entstehen (Kernflow `4e`, Schritt 4: "„…" als neuen Tag anlegen").
 */
import { create } from 'zustand';

import { libraryTags, sampleDocuments, type LibraryTag } from '../data/sampleLibrary';
import { tagColorNames, tagPalette } from '../theme/colors';

interface DocumentState {
  /** Alle bekannten Tags, inklusive der im Tag-Sheet angelegten. */
  tags: LibraryTag[];
  /** Gesetzte Tags je Dokument. */
  tagIds: Record<string, string[]>;
  titles: Record<string, string>;
  notes: Record<string, string>;
  keepOffline: Record<string, boolean>;
  openCounts: Record<string, number>;

  setTitle: (documentId: string, title: string) => void;
  setNote: (documentId: string, note: string) => void;
  setKeepOffline: (documentId: string, keep: boolean) => void;
  /** Beim Oeffnen im Viewer — das Info-Sheet zeigt den Wert als "Geöffnet 12×". */
  countOpen: (documentId: string) => void;

  assignTag: (documentId: string, tagId: string) => void;
  removeTag: (documentId: string, tagId: string) => void;
  /** Legt einen Tag an und gibt ihn zurueck; ein vorhandener Name gewinnt. */
  createTag: (name: string) => LibraryTag;
}

const initialTagIds = Object.fromEntries(
  sampleDocuments.map((document) => [document.id, document.tagIds])
);

const initialTitles = Object.fromEntries(
  sampleDocuments.map((document) => [document.id, document.title])
);

const initialOpenCounts = Object.fromEntries(
  sampleDocuments.map((document) => [document.id, document.openCount])
);

/**
 * Ein neuer Tag bekommt die naechste Farbe der Palette. Reihum statt zufaellig:
 * derselbe Name ergibt bei gleichem Bestand dieselbe Farbe, und zwei kurz
 * nacheinander angelegte Tags sind sicher unterscheidbar.
 */
function nextTagColor(count: number): string {
  return tagPalette[tagColorNames[count % tagColorNames.length]];
}

/** Ausweis aus dem Namen — kleingeschrieben, ohne Leerzeichen. */
function tagIdFromName(name: string): string {
  return name.trim().toLowerCase().replace(/\s+/g, '-');
}

export const useDocumentStore = create<DocumentState>((set, get) => ({
  tags: libraryTags,
  tagIds: initialTagIds,
  titles: initialTitles,
  notes: {},
  keepOffline: {},
  openCounts: initialOpenCounts,

  setTitle: (documentId, title) =>
    set((state) => ({ titles: { ...state.titles, [documentId]: title } })),

  setNote: (documentId, note) => set((state) => ({ notes: { ...state.notes, [documentId]: note } })),

  setKeepOffline: (documentId, keep) =>
    set((state) => ({ keepOffline: { ...state.keepOffline, [documentId]: keep } })),

  countOpen: (documentId) =>
    set((state) => ({
      openCounts: { ...state.openCounts, [documentId]: (state.openCounts[documentId] ?? 0) + 1 },
    })),

  assignTag: (documentId, tagId) =>
    set((state) => {
      const current = state.tagIds[documentId] ?? [];
      if (current.includes(tagId)) return state;
      return { tagIds: { ...state.tagIds, [documentId]: [...current, tagId] } };
    }),

  removeTag: (documentId, tagId) =>
    set((state) => ({
      tagIds: {
        ...state.tagIds,
        [documentId]: (state.tagIds[documentId] ?? []).filter((id) => id !== tagId),
      },
    })),

  createTag: (name) => {
    const trimmed = name.trim();
    const existing = get().tags.find(
      (tag) => tag.name.toLowerCase() === trimmed.toLowerCase()
    );
    if (existing) return existing;

    const tag: LibraryTag = {
      id: tagIdFromName(trimmed),
      name: trimmed,
      color: nextTagColor(get().tags.length),
    };
    set((state) => ({ tags: [...state.tags, tag] }));
    return tag;
  },
}));

/** Tags eines Dokuments als vollstaendige Eintraege, in der gesetzten Reihenfolge. */
export function documentTags(tags: LibraryTag[], ids: string[]): LibraryTag[] {
  return ids
    .map((id) => tags.find((tag) => tag.id === id))
    .filter((tag): tag is LibraryTag => tag !== undefined);
}
