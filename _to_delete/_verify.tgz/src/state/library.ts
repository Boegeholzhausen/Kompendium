/**
 * Zustand der Bibliothek.
 *
 * Das Handoff-Dokument listet unter "State Management" fuer die Bibliothek
 * `viewMode`, `sort`, `activeFilter`, `headerCollapsed`, `selectionMode` und
 * `selectedIds`. Hier liegt, was ueber Screens hinweg gilt und beim
 * Zurueckkehren erhalten bleiben muss:
 *
 *   viewMode      Liste oder Kacheln — gilt auch im Ordner-Detail (Blatt 3b)
 *   sort          zuletzt geaendert / Titel / Groesse
 *   activeFilter  "Alle", "Favoriten" oder ein Tag
 *   favorites     Umschaltungen des Sterns, bis die Datenbank steht
 *
 * `headerCollapsed` gehoert NICHT hierher: der Wert kommt aus dem Scrolloffset
 * und lebt nur, solange der Screen sichtbar ist. `selectionMode` und
 * `selectedIds` folgen mit der Mehrfachauswahl.
 */
import { create } from 'zustand';

import { sampleDocuments } from '../data/sampleLibrary';

export type ViewMode = 'list' | 'grid';
export type SortKey = 'recent' | 'title' | 'size';
/** 'all' | 'favorites' | Tag-Ausweis */
export type LibraryFilter = string;

export const sortLabels: Record<SortKey, string> = {
  recent: 'Zuletzt geändert',
  title: 'Titel',
  size: 'Größe',
};

interface LibraryState {
  viewMode: ViewMode;
  sort: SortKey;
  activeFilter: LibraryFilter;
  /** Ueberlagert `favorite` aus dem Bestand, solange es keine Datenbank gibt. */
  favorites: Record<string, boolean>;
  toggleViewMode: () => void;
  setSort: (sort: SortKey) => void;
  setFilter: (filter: LibraryFilter) => void;
  toggleFavorite: (id: string) => void;
}

const initialFavorites = Object.fromEntries(
  sampleDocuments.filter((document) => document.favorite).map((document) => [document.id, true])
);

export const useLibraryStore = create<LibraryState>((set) => ({
  viewMode: 'list',
  sort: 'recent',
  activeFilter: 'all',
  favorites: initialFavorites,
  toggleViewMode: () => set((state) => ({ viewMode: state.viewMode === 'list' ? 'grid' : 'list' })),
  setSort: (sort) => set({ sort }),
  setFilter: (activeFilter) => set({ activeFilter }),
  toggleFavorite: (id) =>
    set((state) => ({ favorites: { ...state.favorites, [id]: !state.favorites[id] } })),
}));
