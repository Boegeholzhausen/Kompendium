/**
 * Screen 14 — Einstellungen (Blatt `3i`). Kommt in Schritt 7.
 *
 * Bis dahin haengen hier die Abnahmeblaetter: sie waren vorher der Einstieg
 * der App und sollen erreichbar bleiben, ohne die Bibliothek zu verdecken.
 */
import React from 'react';
import { router } from 'expo-router';

import { Placeholder } from '../../src/screens/Placeholder';
import { SecondaryButton } from '../../src/ui/Button';

export default function SettingsRoute() {
  return (
    <Placeholder
      title="Einstellungen"
      note="Die Einstellungen mit Papierkorb und Darstellung entstehen in Schritt 7."
    >
      <SecondaryButton label="Abnahmeblätter" onPress={() => router.push('/abnahme')} />
    </Placeholder>
  );
}
