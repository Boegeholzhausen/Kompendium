/**
 * Tab-Rahmen — vier Ziele: Bibliothek, Ordner, Tags, Einstellungen.
 *
 * Die Tab-Bar ist die Komponente 14 aus Schritt 3, nicht die eingebaute:
 * Flaechen, Schriftschnitte und der `fill`-Wechsel des aktiven Icons stecken
 * dort. Der Navigator liefert nur Zustand und Ziel.
 *
 * Suchscreen, Viewer, Ordner-Detail, Papierkorb und Darstellung liegen als
 * Push-Screens ueber diesem Rahmen und zeigen keine Tab-Bar — sie gehoeren
 * deshalb in den Stack eine Ebene hoeher, nicht hierher.
 */
import React from 'react';
import { Tabs } from 'expo-router/js-tabs';

import { bg } from '../../src/theme/colors';
import { Books, Folders, Gear, Tag } from '../../src/ui/icons';
import { TabBar, type TabItem } from '../../src/ui/TabBar';

const items: TabItem[] = [
  { key: 'index', label: 'Bibliothek', icon: Books },
  { key: 'ordner', label: 'Ordner', icon: Folders },
  { key: 'tags', label: 'Tags', icon: Tag },
  { key: 'einstellungen', label: 'Einstellungen', icon: Gear },
];

export default function TabsLayout() {
  return (
    <Tabs
      screenOptions={{
        headerShown: false,
        sceneStyle: { backgroundColor: bg.base },
      }}
      tabBar={({ state, navigation }) => (
        <TabBar
          items={items}
          value={state.routes[state.index]?.name ?? 'index'}
          onChange={(key) => navigation.navigate(key)}
        />
      )}
    >
      {items.map((item) => (
        <Tabs.Screen key={item.key} name={item.key} options={{ title: item.label }} />
      ))}
    </Tabs>
  );
}
