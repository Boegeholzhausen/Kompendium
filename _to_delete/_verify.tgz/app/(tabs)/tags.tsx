/** Screen 11 — Tag-Verwaltung (Blatt `3f`). Kommt in Schritt 6. */
import React from 'react';

import { Placeholder } from '../../src/screens/Placeholder';

export default function TagsRoute() {
  return (
    <Placeholder
      title="Tags"
      note="Die Tag-Verwaltung entsteht in Schritt 6, zusammen mit Ordnern, Suche und Import."
    />
  );
}
