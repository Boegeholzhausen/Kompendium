/** Screen 3 — Ordner-Uebersicht (Blatt `3a`). Kommt in Schritt 6. */
import React from 'react';

import { Placeholder } from '../../src/screens/Placeholder';

export default function FoldersRoute() {
  return (
    <Placeholder
      title="Ordner"
      note="Die Ordner-Übersicht entsteht in Schritt 6, zusammen mit Tags, Suche und Import."
    />
  );
}
