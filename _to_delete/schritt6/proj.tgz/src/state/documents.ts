/**
 * Zustand einzelner Dokumente — alles, was das Info- und das Tag-Sheet aendern.
 *
 * Das Handoff-Dokument listet unter "State Management" fuer ein Dokument
 * `title`, `folderId`, `tagIds[]`, `note`, `isFavorite`, `keepOffline`,
 * `openCount` und weitere Felder. Die Wahrheitsquelle wird expo-sqlite; bis
 * dahin liegen die Aenderungen hier als Ueberlagerung ueber dem Bestand aus
 * `src/data/sampleLibrary`. Die Screens fragen nur diesen Zustand — der
 * Wechsel auf die Datenbank beruehrt keine Komponente.
 *
 * `isFavorite` bleibt bewusst im Bibliothek-Zustand: der Stern gehoert zur
 * Zeile und wird dort seit Schritt 4 umgeschaltet. Zwei Speicherorte fuer
 * denselben Schalter waeren eine Fehlerquelle.
 *
 * Die Tag-Liste liegt ebenfalls hier und nicht im Bestand, weil neue Tags im
 * Tag-Sheet entstehen (Kernflow `4e`, Schritt 4: "„…" als neuen Tag anlegen").
 */
import { create } from 'zustand';

import { libraryTags, sampleDocuments, type LibraryTag } from '../data/sampleLibrary';
import { tagColorNames, tagPalette } from '../theme/colors';

interface DocumentState {
  /** Alle bekannten Tags, inklusive der im Tag-Sheet angelegten. */
  tags: LibraryTag[];
  /** Gesetzte Tags je Dokument. */
  tagIds: Record<string, string[]>;
  titles: Record<string, string>;
  /**
   * Ordner je Dokument, `null` = nicht einsortiert. Seit Schritt 6 liegt die
   * Zuordnung hier und nicht mehr nur im Bestand: das Verschieben-Sheet und die
   * Mehrfachauswahl aendern sie, und die Sektion "Neu" leert sich dadurch.
   */
  folderNames: Record<string, string | null>;
  notes: Record<string, string>;
  keepOffline: Record<string, boolean>;
  openCounts: Record<string, number>;
  /**
   * Zeitpunkt des Loeschens je Dokument. Der Papierkorb-Screen entsteht erst in
   * Schritt 7; die Aktion "Loeschen" der Auswahl-Aktionsleiste (Blatt `3h`)
   * gibt es aber schon in Schritt 6, und eine Schaltflaeche ohne Wirkung waere
   * schlechter als ein kleiner Vorgriff. Geloeschte Dokumente verschwinden aus
   * allen Listen, der Toast holt sie fuenf Sekunden lang zurueck.
   */
  trashedAt: Record<string, number>;

  setTitle: (documentId: string, title: string) => void;
  setNote: (documentId: string, note: string) => void;
  setKeepOffline: (documentId: string, keep: boolean) => void;
  /** Beim Oeffnen im Viewer — das Info-Sheet zeigt den Wert als "Geöffnet 12×". */
  countOpen: (documentId: string) => void;

  /** Einzeln oder als Mehrfachauswahl: Dokumente in einen Ordner legen. */
  setFolder: (documentIds: string[], folderName: string | null) => void;
  /** Zweite Haelfte des Ordner-Umbenennens (siehe `state/folders.ts`). */
  renameFolderEverywhere: (from: string, to: string) => void;

  /** In den Papierkorb legen; `at` als Parameter, damit das Ergebnis pruefbar bleibt. */
  trash: (documentIds: string[], at?: number) => void;
  restoreFromTrash: (documentIds: string[]) => void;

  assignTag: (documentId: string, tagId: string) => void;
  removeTag: (documentId: string, tagId: string) => void;
  /** Legt einen Tag an und gibt ihn zurueck; ein vorhandener Name gewinnt. */
  createTag: (name: string) => LibraryTag;
  /** Tag-Verwaltung: benennt um, ohne den Ausweis zu aendern. */
  renameTag: (tagId: string, name: string) => void;
  /** Tag-Verwaltung: entfernt den Tag ueberall — sonst blieben tote Ausweise. */
  deleteTag: (tagId: string) => void;
  /** Zuruecknehmen eines geloeschten Tags (Toast "Rueckgaengig"). */
  restoreTag: (tag: LibraryTag, documentIds: string[]) => void;
}

const initialTagIds = Object.fromEntries(
  sampleDocuments.map((document) => [document.id, document.tagIds])
);

const initialTitles = Object.fromEntries(
  sampleDocuments.map((document) => [document.id, document.title])
);

const initialOpenCounts = Object.fromEntries(
  sampleDocuments.map((document) => [document.id, document.openCount])
);

const initialFolderNames = Object.fromEntries(
  sampleDocuments.map((document) => [document.id, document.folderName])
);

/**
 * Ein neuer Tag bekommt die naechste Farbe der Palette. Reihum statt zufaellig:
 * derselbe Name ergibt bei gleichem Bestand dieselbe Farbe, und zwei kurz
 * nacheinander angelegte Tags sind sicher unterscheidbar.
 */
function nextTagColor(count: number): string {
  return tagPalette[tagColorNames[count % tagColorNames.length]];
}

/** Ausweis aus dem Namen — kleingeschrieben, ohne Leerzeichen. */
function tagIdFromName(name: string): string {
  return name.trim().toLowerCase().replace(/\s+/g, '-');
}

export const useDocumentStore = create<DocumentState>((set, get) => ({
  tags: libraryTags,
  tagIds: initialTagIds,
  titles: initialTitles,
  folderNames: initialFolderNames,
  notes: {},
  keepOffline: {},
  openCounts: initialOpenCounts,
  trashedAt: {},

  setTitle: (documentId, title) =>
    set((state) => ({ titles: { ...state.titles, [documentId]: title } })),

  setNote: (documentId, note) => set((state) => ({ notes: { ...state.notes, [documentId]: note } })),

  setKeepOffline: (documentId, keep) =>
    set((state) => ({ keepOffline: { ...state.keepOffline, [documentId]: keep } })),

  countOpen: (documentId) =>
    set((state) => ({
      openCounts: { ...state.openCounts, [documentId]: (state.openCounts[documentId] ?? 0) + 1 },
    })),

  setFolder: (documentIds, folderName) =>
    set((state) => {
      const next = { ...state.folderNames };
      for (const id of documentIds) next[id] = folderName;
      return { folderNames: next };
    }),

  renameFolderEverywhere: (from, to) =>
    set((state) => {
      const next: Record<string, string | null> = {};
      for (const [id, name] of Object.entries(state.folderNames)) {
        next[id] = name === from ? to : name;
      }
      return { folderNames: next };
    }),

  trash: (documentIds, at) =>
    set((state) => {
      const stamp = at ?? Date.now();
      const next = { ...state.trashedAt };
      for (const id of documentIds) next[id] = stamp;
      return { trashedAt: next };
    }),

  restoreFromTrash: (documentIds) =>
    set((state) => {
      const next = { ...state.trashedAt };
      for (const id of documentIds) delete next[id];
      return { trashedAt: next };
    }),

  assignTag: (documentId, tagId) =>
    set((state) => {
      const current = state.tagIds[documentId] ?? [];
      if (current.includes(tagId)) return state;
      return { tagIds: { ...state.tagIds, [documentId]: [...current, tagId] } };
    }),

  removeTag: (documentId, tagId) =>
    set((state) => ({
      tagIds: {
        ...state.tagIds,
        [documentId]: (state.tagIds[documentId] ?? []).filter((id) => id !== tagId),
      },
    })),

  createTag: (name) => {
    const trimmed = name.trim();
    const existing = get().tags.find(
      (tag) => tag.name.toLowerCase() === trimmed.toLowerCase()
    );
    if (existing) return existing;

    const tag: LibraryTag = {
      id: tagIdFromName(trimmed),
      name: trimmed,
      color: nextTagColor(get().tags.length),
    };
    set((state) => ({ tags: [...state.tags, tag] }));
    return tag;
  },

  /**
   * Der Ausweis bleibt, nur der Name aendert sich. Sonst muessten alle
   * Dokumente umgeschrieben werden, und ein Aussetzer mittendrin liesse Tags
   * zurueck, die es nicht mehr gibt.
   */
  renameTag: (tagId, name) =>
    set((state) => ({
      tags: state.tags.map((tag) => (tag.id === tagId ? { ...tag, name: name.trim() } : tag)),
    })),

  deleteTag: (tagId) =>
    set((state) => {
      const next: Record<string, string[]> = {};
      for (const [id, ids] of Object.entries(state.tagIds)) {
        next[id] = ids.includes(tagId) ? ids.filter((entry) => entry !== tagId) : ids;
      }
      return { tags: state.tags.filter((tag) => tag.id !== tagId), tagIds: next };
    }),

  restoreTag: (tag, documentIds) =>
    set((state) => {
      const next = { ...state.tagIds };
      for (const id of documentIds) {
        const current = next[id] ?? [];
        if (!current.includes(tag.id)) next[id] = [...current, tag.id];
      }
      return { tags: [...state.tags, tag], tagIds: next };
    }),
}));

/** Liegt das Dokument im Papierkorb? Listen blenden es dann aus. */
export function isTrashed(trashedAt: Record<string, number>, documentId: string): boolean {
  return trashedAt[documentId] !== undefined;
}

/** Tags eines Dokuments als vollstaendige Eintraege, in der gesetzten Reihenfolge. */
export function documentTags(tags: LibraryTag[], ids: string[]): LibraryTag[] {
  return ids
    .map((id) => tags.find((tag) => tag.id === id))
    .filter((tag): tag is LibraryTag => tag !== undefined);
}
