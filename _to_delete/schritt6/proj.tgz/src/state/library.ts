/**
 * Zustand der Bibliothek.
 *
 * Das Handoff-Dokument listet unter "State Management" fuer die Bibliothek
 * `viewMode`, `sort`, `activeFilter`, `headerCollapsed`, `selectionMode` und
 * `selectedIds`. Hier liegt, was ueber Screens hinweg gilt und beim
 * Zurueckkehren erhalten bleiben muss:
 *
 *   viewMode      Liste oder Kacheln — gilt auch im Ordner-Detail (Blatt 3b)
 *   sort          zuletzt geaendert / Titel / Groesse
 *   activeFilter  "Alle", "Favoriten" oder ein Tag
 *   favorites     Umschaltungen des Sterns, bis die Datenbank steht
 *
 *   selectionMode Mehrfachauswahl aktiv (Blatt `3h`)
 *   selectedIds   die gewaehlten Dokumente
 *
 * `headerCollapsed` gehoert NICHT hierher: der Wert kommt aus dem Scrolloffset
 * und lebt nur, solange der Screen sichtbar ist.
 *
 * `selectedIds` ist eine Liste, kein Set: der Zustand wird bei jeder Aenderung
 * ersetzt, und eine Liste laesst sich unveraendert kopieren, ohne dass ein
 * Vergleich in zustand danebengreift.
 */
import { create } from 'zustand';

import { sampleDocuments } from '../data/sampleLibrary';

export type ViewMode = 'list' | 'grid';
export type SortKey = 'recent' | 'title' | 'size';
/** 'all' | 'favorites' | Tag-Ausweis */
export type LibraryFilter = string;

/**
 * Was die Auswahl-Aktionsleiste anfordert.
 *
 * Die Leiste ersetzt die Tab-Bar und lebt deshalb im Tab-Rahmen, die Sheets
 * und der Toast aber in der Bibliothek. Statt Rueckrufe durch den Navigator zu
 * faedeln, legt die Leiste hier einen Wunsch ab; die Bibliothek nimmt ihn auf
 * und raeumt ihn wieder weg. Eine Stelle, ein Weg.
 */
export type SelectionRequest = 'move' | 'tag' | 'favorite' | 'trash';

export const sortLabels: Record<SortKey, string> = {
  recent: 'Zuletzt geändert',
  title: 'Titel',
  size: 'Größe',
};

interface LibraryState {
  viewMode: ViewMode;
  sort: SortKey;
  activeFilter: LibraryFilter;
  /** Ueberlagert `favorite` aus dem Bestand, solange es keine Datenbank gibt. */
  favorites: Record<string, boolean>;
  selectionMode: boolean;
  selectedIds: string[];
  /** Wunsch der Auswahl-Aktionsleiste, den die Bibliothek ausfuehrt. */
  request: SelectionRequest | null;
  toggleViewMode: () => void;
  setSort: (sort: SortKey) => void;
  setFilter: (filter: LibraryFilter) => void;
  toggleFavorite: (id: string) => void;
  /** Mehrere auf einmal — die Auswahl-Aktionsleiste setzt, sie schaltet nicht um. */
  setFavorite: (ids: string[], value: boolean) => void;
  /** Langer Druck auf eine Zeile: Modus an, diese Zeile gewaehlt. */
  startSelection: (id: string) => void;
  /** "Einsortieren" in der Sektion "Neu": Modus an, alle Neuen gewaehlt. */
  startSelectionWith: (ids: string[]) => void;
  setRequest: (request: SelectionRequest | null) => void;
  toggleSelected: (id: string) => void;
  endSelection: () => void;
}

const initialFavorites = Object.fromEntries(
  sampleDocuments.filter((document) => document.favorite).map((document) => [document.id, true])
);

export const useLibraryStore = create<LibraryState>((set) => ({
  viewMode: 'list',
  sort: 'recent',
  activeFilter: 'all',
  favorites: initialFavorites,
  selectionMode: false,
  selectedIds: [],
  request: null,
  toggleViewMode: () => set((state) => ({ viewMode: state.viewMode === 'list' ? 'grid' : 'list' })),
  setSort: (sort) => set({ sort }),
  setFilter: (activeFilter) => set({ activeFilter }),
  toggleFavorite: (id) =>
    set((state) => ({ favorites: { ...state.favorites, [id]: !state.favorites[id] } })),

  setFavorite: (ids, value) =>
    set((state) => {
      const next = { ...state.favorites };
      for (const id of ids) next[id] = value;
      return { favorites: next };
    }),

  startSelection: (id) => set({ selectionMode: true, selectedIds: [id] }),

  startSelectionWith: (ids) => set({ selectionMode: true, selectedIds: ids }),

  setRequest: (request) => set({ request }),

  /**
   * Die letzte Abwahl beendet den Modus nicht: "0 ausgewählt" ist ein
   * gueltiger Zustand, und ein Screen, der beim vorletzten Tipp umspringt,
   * ueberrascht mehr als er hilft. Beendet wird ueber "Abbrechen".
   */
  toggleSelected: (id) =>
    set((state) => ({
      selectedIds: state.selectedIds.includes(id)
        ? state.selectedIds.filter((entry) => entry !== id)
        : [...state.selectedIds, id],
    })),

  endSelection: () => set({ selectionMode: false, selectedIds: [], request: null }),
}));
