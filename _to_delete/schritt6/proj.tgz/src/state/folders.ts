/**
 * Zustand der Ordner.
 *
 * Das Handoff-Dokument fuehrt am Dokument ein `folderId`. Der Beispiel-Bestand
 * kennt bisher nur `folderName`, und die Screens (Blatt `3a`, `3b`, `2d`)
 * zeigen ueberall den Namen. Solange die Datenbank fehlt, ist der Name deshalb
 * zugleich der Ausweis — das erspart eine Ausweistabelle, die beim Wechsel auf
 * expo-sqlite ohnehin neu entsteht.
 *
 * Folge davon: Umbenennen muss an zwei Stellen wirken — hier und in der
 * Ordner-Zuordnung der Dokumente (`documents.ts`). Beides zusammen erledigt
 * `renameFolderEverywhere` in den Screens; getrennte Aufrufe waeren eine
 * Fehlerquelle.
 *
 * Die Ordnerfarbe traegt laut Handoff-Dokument nur das Icon, nie eine Flaeche.
 * Sechs Farben stehen zur Wahl (Screen 17), nicht acht.
 */
import { create } from 'zustand';

import { folderColor, sampleDocuments } from '../data/sampleLibrary';
import { folderColorNames, tagPalette, type FolderColorName } from '../theme/colors';

export interface LibraryFolder {
  /** Zugleich Ausweis, siehe Kopfkommentar. */
  name: string;
  /** Farbe aus der Tag-Palette, sechs zur Auswahl. */
  color: string;
  /** "Inhalt offline behalten" — gilt fuer alles im Ordner (Screen 17). */
  keepOffline: boolean;
}

/** Die sechs waehlbaren Ordnerfarben als Wertepaare fuer die Farbkacheln. */
export const folderColorChoices: { key: FolderColorName; value: string }[] = folderColorNames.map(
  (key) => ({ key, value: tagPalette[key] })
);

/**
 * Ausgangsbestand: die Ordner, die im Beispiel-Bestand vorkommen, in der
 * Reihenfolge ihres ersten Auftretens. Die Farbe kommt aus `sampleLibrary`,
 * damit Blatt `3a` (Finanzen in `sky`) und Blatt `2d` dieselbe zeigen.
 */
function initialFolders(): LibraryFolder[] {
  const names: string[] = [];
  for (const document of sampleDocuments) {
    if (document.folderName !== null && !names.includes(document.folderName)) {
      names.push(document.folderName);
    }
  }
  return names.map((name) => ({ name, color: folderColor(name), keepOffline: false }));
}

interface FolderState {
  folders: LibraryFolder[];
  /** Legt an; ein vorhandener Name gewinnt, damit nichts doppelt entsteht. */
  createFolder: (name: string, color: string, keepOffline: boolean) => LibraryFolder;
  renameFolder: (from: string, to: string) => void;
  setKeepOffline: (name: string, keep: boolean) => void;
}

export const useFolderStore = create<FolderState>((set, get) => ({
  folders: initialFolders(),

  createFolder: (name, color, keepOffline) => {
    const trimmed = name.trim();
    const existing = get().folders.find(
      (folder) => folder.name.toLowerCase() === trimmed.toLowerCase()
    );
    if (existing) return existing;

    const folder: LibraryFolder = { name: trimmed, color, keepOffline };
    set((state) => ({ folders: [...state.folders, folder] }));
    return folder;
  },

  renameFolder: (from, to) =>
    set((state) => ({
      folders: state.folders.map((folder) =>
        folder.name === from ? { ...folder, name: to.trim() } : folder
      ),
    })),

  setKeepOffline: (name, keep) =>
    set((state) => ({
      folders: state.folders.map((folder) =>
        folder.name === name ? { ...folder, keepOffline: keep } : folder
      ),
    })),
}));

/** Farbe eines Ordners aus dem Zustand; unbekannte Namen bleiben neutral. */
export function colorOf(folders: LibraryFolder[], name: string | null): string {
  if (name === null) return tagPalette.slate;
  return folders.find((folder) => folder.name === name)?.color ?? tagPalette.slate;
}
