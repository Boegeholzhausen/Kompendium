/**
 * Screen 12 · Import-Sheet (Blatt `3g`) — hinter dem FAB der Bibliothek.
 *
 * Drei **gleichwertige** Auswahlflaechen untereinander: Datei waehlen, aus
 * Zwischenablage, von URL laden. Keine ist als Mint-Button ausgezeichnet — sie
 * sind gleichwertige Wege, eine Vorauswahl waere geraten. Mint traegt nur das
 * Icon.
 *
 * Die Fussnote sagt, wo das Dokument danach auftaucht; das nimmt der Sektion
 * "Neu" die Erklaerungslast ab.
 *
 * Stand Schritt 6: das Sheet ist gebaut, die drei Wege sind es noch nicht. Sie
 * brauchen den lokalen Dateicache (expo-file-system) und die Typerkennung beim
 * Import — beides gehoert zur Datenschicht und nicht zu den Screens. Bis dahin
 * sagt eine Zeile im Sheet ehrlich, was fehlt, statt still nichts zu tun.
 */
import React from 'react';
import { StyleSheet, View } from 'react-native';

import { accent, bg, border, iconSize, radius, size, space, text as textColor } from '../../theme';
import { BottomSheet } from '../../ui/BottomSheet';
import { CaretRight, ClipboardText, FileHtml, LinkSimple, type Icon } from '../../ui/icons';
import { PressableScale } from '../../ui/press';
import { Text } from '../../ui/Text';

interface ImportWay {
  key: string;
  icon: Icon;
  title: string;
  note: string;
}

const ways: ImportWay[] = [
  { key: 'file', icon: FileHtml, title: 'Datei wählen', note: 'HTML-Datei vom Gerät' },
  { key: 'clipboard', icon: ClipboardText, title: 'Aus Zwischenablage', note: 'HTML-Code einfügen' },
  { key: 'url', icon: LinkSimple, title: 'Von URL laden', note: 'Adresse eingeben' },
];

export interface ImportSheetProps {
  visible: boolean;
  onClose: () => void;
  /** Wird gerufen, sobald ein Weg gewaehlt wurde — noch ohne Wirkung. */
  onChoose?: (key: string) => void;
}

export function ImportSheet({ visible, onClose, onChoose }: ImportSheetProps) {
  return (
    <BottomSheet visible={visible} title="Dokument hinzufügen" onClose={onClose}>
      <View style={styles.ways}>
        {ways.map((way) => {
          const WayIcon = way.icon;
          return (
            <PressableScale
              key={way.key}
              style={styles.way}
              pressedStyle={styles.wayPressed}
              scaleOnPress={false}
              onPress={() => onChoose?.(way.key)}
              accessibilityRole="button"
              accessibilityLabel={`${way.title}. ${way.note}`}
            >
              <WayIcon size={iconSize.lg} color={accent.base} weight="regular" />
              <View style={styles.wayBody}>
                <Text variant="title">{way.title}</Text>
                <Text variant="bodySm" tone="secondary" style={styles.wayNote}>
                  {way.note}
                </Text>
              </View>
              <CaretRight size={18} color={textColor.tertiary} weight="regular" />
            </PressableScale>
          );
        })}
      </View>

      <Text variant="label" tone="tertiary" style={styles.footnote}>
        Importierte Dokumente landen in „Neu", bis sie einsortiert sind.
      </Text>
    </BottomSheet>
  );
}

const styles = StyleSheet.create({
  ways: {
    gap: space['12'],
  },
  way: {
    flexDirection: 'row',
    alignItems: 'center',
    gap: size.cardPadding,
    paddingVertical: space['16'] + space['2'],
    paddingHorizontal: size.screenPadding,
    borderRadius: radius.md,
    backgroundColor: bg.raised,
    borderWidth: 1,
    borderColor: border.strong,
  },
  wayPressed: {
    backgroundColor: bg.overlay,
  },
  wayBody: {
    flex: 1,
  },
  wayNote: {
    marginTop: space['2'],
  },
  footnote: {
    marginTop: size.screenPadding,
    marginBottom: space['8'],
  },
});
